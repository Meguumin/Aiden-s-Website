Version 1.0

Controls are pretty simple.

Play and Stop only works on selected songs.

Use the Left Mouse button to work controls

Reset starts song from the start.

Add songs via songs folder.